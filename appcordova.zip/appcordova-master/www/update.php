<?php
 include "db.php";
 if(isset($_POST['update']))
 {
 $id_barang=$_POST['id_barang'];
 $nama_barang=$_POST['nama_barang'];
 $harga=$_POST['harga'];
 $jumlah=$_POST['jumlah'];
 $q=mysqli_query($con,"UPDATE `gudang` SET `id_barang`='$id_barang',`nama_barang`='$nama_barang',`harga`='$harga',`jumlah`='$jumlah' where `id_barang`='$id_barang'");
 if($q)
 echo "success";
 else
 echo "error";
 }
 ?>