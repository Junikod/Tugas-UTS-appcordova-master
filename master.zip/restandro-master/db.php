<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id8312192_junikods","12345678","id8312192_junikod1") or die ("could not connect database");
